package com.mb.auto.jira.api;

public interface MyPluginComponent
{
    String getName();
}